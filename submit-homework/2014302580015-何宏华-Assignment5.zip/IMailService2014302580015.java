package iss.java.mail;

import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.internet.MimeMessage.RecipientType;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;


public class IMailService2014302580015 {
	public static MailAuthenticator2014302580015 authenticator;
	public static Session session;
    public static  void connect() throws MessagingException{
    		String smtpHostname="smtp.139.com";
    		String username="18798725347@139.com";
    		String password="520966";
    		final Properties props=System.getProperties(); 
    		props.put("mail.smtp.auth", "true");
    		props.put("mail.smtp.host",smtpHostname);
    		authenticator=new MailAuthenticator2014302580015(username,password);
    		session=Session.getInstance(props,authenticator);	
		
    }
    public static void send(String recipient, String subject, Object content) throws MessagingException{
    		final MimeMessage message=new MimeMessage(session);
			message.setFrom(new InternetAddress(authenticator.getUsername()));
			message.setRecipient(RecipientType.TO,new InternetAddress(recipient));
			message.setSubject(subject);
			message.setContent(content.toString(),"text/html;charset=utf-8");
			Transport.send(message);
    }
 
    public static boolean listen() throws MessagingException{
    	String pop3Hostname="pop3.139.com";
		String username="18798725347@139.com";
		String password="520966";
		final Properties props=System.getProperties(); 
		props.put("mail.store.protocol", "pop3");
		props.put("mail.pop3.host",pop3Hostname);
		authenticator=new MailAuthenticator2014302580015(username,password);
		session=Session.getInstance(props,authenticator);
		Store store = session.getStore();
        store.connect();
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);
        int a=folder.getUnreadMessageCount();
        folder.close(false);
        store.close();
        if(a>0){
        	System.out.println("�����µ��ʼ���");
        	return true;
        	
        }
        else {
        	System.out.println("û���յ��ʼ���");
        	return false;
        }
    }

    public static String getReplyMessageContent(String sender) throws MessagingException, IOException {
    	 Store store = session.getStore();
         store.connect();
         String subject1;
         String from;
         String content = null;
         // ��������ڵ��ʼ���Folder������"ֻ��"��
         Folder folder = store.getFolder("inbox");
         folder.open(Folder.READ_ONLY);

         Message[] messages = folder.getMessages();

         int mailCounts = messages.length;
        // System.out.println(mailCounts);
         for(int i = 0; i < mailCounts; i++) {

        	 subject1 = messages[i].getSubject();
        	 from = (messages[i].getFrom()[0]).toString();
             if(from.contains(sender)){
             System.out.println("�յ��Զ��ظ��ʼ�");
             System.out.println("���⣺" + subject1);
             System.out.println("�����ˣ�897226453@qq.com");
             content=messages[i].getContent().toString();
             }
         }
         folder.close(false);
         store.close();
         return content;
     }
}
