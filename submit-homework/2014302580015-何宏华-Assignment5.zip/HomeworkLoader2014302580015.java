package iss.java.mail;


import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Random;


public class HomeworkLoader2014302580015 {
    public static void main(String[] args) throws MessagingException, IOException, InterruptedException, IllegalAccessException, InstantiationException {
        String id ="2014302580015";
        System.out.println(id);
        IMailService2014302580015.connect();
        int random = new Random().nextInt(3);
        System.out.println("mail ID: "+random);
        IMailService2014302580015.send("issjava2015@foxmail.com", "java��ҵ"+random+"_"+id,"����");
        System.out.println("mail sent");
        for(int i = 0;i<30;i++){
            if(IMailService2014302580015.listen()){
                System.out.println(IMailService2014302580015.getReplyMessageContent("issjava2015@foxmail.com"));
                System.out.println("check if your mail id and verify id match");
                return;
            }
            System.out.println("waiting for auto reply");
            Thread.sleep(5000);
        }
        System.out.println("time out");
    }
}
